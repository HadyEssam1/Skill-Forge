package service;

import managers.CourseJsonManager;
import managers.UserJsonManager;
import models.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Analytics {
    private CourseJsonManager courseManager;
    private UserJsonManager userManager;
    private CourseService courseService;
    private StudentService studentService;

    public Analytics(CourseJsonManager courseManager, UserJsonManager userManager,
                     CourseService courseService, StudentService studentService) throws Exception {
        this.courseManager = courseManager;
        this.userManager = userManager;
        this.courseService = courseService;
        this.studentService = studentService;
    }

    private List<User> safeUsers() {
        List<User> users = userManager.getAll();
        return (users != null) ? users : new ArrayList<>();
    }

    public double getLessonQuizAverage(int courseId, int lessonId) throws Exception {
        Course course = courseManager.getById(courseId);
        if (course == null) return 0;

        List<Integer> studentIds = course.getStudentIds();
        List<User> users = safeUsers();

        int sum = 0, count = 0;

        for (Integer sid : studentIds) {
            for (User u : users) {
                if (u.getUserId() == sid && u instanceof Student s) {

                    int quizId = courseService.getQuizIdByLesson(courseId, lessonId);

                    QuizAttempt best = studentService.getBestAttempt(s.getUserId(), quizId);
                    if (best != null) {
                        sum += best.getScore();
                        count++;
                    }
                }
            }
        }
        return count == 0 ? 0 : (sum * 1.0) / count;
    }

    public Map<Integer, Double> getLessonQuizAverages(int courseId) throws Exception {
        Map<Integer, Double> lessonAverages = new HashMap<>();
        Course course = courseManager.getById(courseId);
        if (course == null) return lessonAverages;

        for (Lesson lesson : course.getLessons()) {
            double avg = getLessonQuizAverage(courseId, lesson.getLessonId());
            lessonAverages.put(lesson.getLessonId(), avg);
        }
        return lessonAverages;
    }

    public double getCourseCompletionRate(int courseId) throws Exception {
        Course course = courseManager.getById(courseId);
        if (course == null) return 0;

        List<Integer> studentIds = course.getStudentIds();
        List<Lesson> lessons = course.getLessons();
        if (studentIds.isEmpty() || lessons.isEmpty()) return 0;

        List<User> users = safeUsers();

        int totalLessons = lessons.size();
        int totalStudents = studentIds.size();
        int totalCompleted = 0;

        for (Integer studentId : studentIds) {
            for (User u : users) {
                if (u.getUserId() == studentId && u instanceof Student s) {
                    for (Lesson lesson : lessons) {
                        if (s.getLessonProgress(courseId, lesson.getLessonId())) {
                            totalCompleted++;
                        }
                    }
                }
            }
        }

        int totalPossible = totalStudents * totalLessons;
        return (totalCompleted * 100.0) / totalPossible;
    }

    public Map<String, Double> getStudentProgressForCourse(int courseId) throws Exception {
        Map<String, Double> progressMap = new HashMap<>();
        Course course = courseManager.getById(courseId);
        if (course == null) return progressMap;

        List<Integer> studentIds = course.getStudentIds();
        List<Lesson> lessons = course.getLessons();
        List<User> users = safeUsers();

        int totalLessons = lessons.size();

        for (Integer sid : studentIds) {
            for (User u : users) {
                if (u.getUserId() == sid && u instanceof Student s) {

                    int completed = 0;
                    for (Lesson lesson : lessons) {
                        if (s.getLessonProgress(courseId, lesson.getLessonId())) {
                            completed++;
                        }
                    }

                    double percent = (completed * 100.0) / totalLessons;
                    progressMap.put(s.getUsername(), percent);
                }
            }
        }

        return progressMap;
    }

    public Map<String, Object> getInstructorInsights(int courseId) throws Exception {
        Map<String, Object> data = new HashMap<>();
        Course course = courseManager.getById(courseId);
        if (course == null) return data;

        data.put("completionRate", getCourseCompletionRate(courseId));

        Map<Integer, Double> lessonAverages = new HashMap<>();
        for (Lesson lesson : course.getLessons()) {
            double avg = getLessonQuizAverage(courseId, lesson.getLessonId());
            lessonAverages.put(lesson.getLessonId(), avg);
        }
        data.put("quizAverages", lessonAverages);

        data.put("studentProgress", getStudentProgressForCourse(courseId));

        return data;
    }
}
